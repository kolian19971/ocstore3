<?php
// Text
$_['text_title'] = 'Безкоштовне замовлення';