<?php
$_['text_credit'] = 'Кредит Магазину';
$_['text_order_id'] = '№ Замовлення: %s';