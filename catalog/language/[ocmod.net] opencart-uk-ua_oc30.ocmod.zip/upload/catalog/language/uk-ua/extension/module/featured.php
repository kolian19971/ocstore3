<?php
// Heading
$_['heading_title'] = 'Рекомендовані';

// Text
$_['text_tax'] = 'Без ПДВ:';