<?php
// Heading
$_['heading_title'] = 'Хіт продажів';

// Text
$_['text_tax'] = 'Без ПДВ:';