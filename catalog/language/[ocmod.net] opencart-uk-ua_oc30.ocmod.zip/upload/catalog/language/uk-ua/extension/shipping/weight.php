<?php
// Text
$_['text_title'] = 'Доставка в залежності від ваги';
$_['text_weight'] = 'Вага:';