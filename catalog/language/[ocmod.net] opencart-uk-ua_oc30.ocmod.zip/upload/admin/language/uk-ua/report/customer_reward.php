<?php
// Heading
$_['heading_title'] = 'Звіт з бонусними балами клієнта';

// Text
$_['text_list'] = 'Бонусні бали клієнтів';

// Column
$_['column_customer'] = 'Ім&#39;я клієнта';
$_['column_email'] = 'E-Mail';
$_['column_customer_group'] = 'Група клієнта';
$_['column_status'] = 'Статус';
$_['column_points'] = 'Бонусні бали';
$_['column_orders'] = 'Кількість замовлень';
$_['column_total'] = 'Разом';
$_['column_action'] = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
$_['entry_customer'] = 'Клієнт';