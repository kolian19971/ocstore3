<?php
// Heading
$_['heading_title'] = 'Модулі / Розширення';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Розширення';
$_['text_type'] = 'Виберіть тип розширення';
$_['text_filter'] = 'Фільтр';
$_['text_analytics'] = 'Аналітика';
$_['text_captcha'] = 'Захист від роботів';
$_['text_dashboard'] = 'Панель управління';
$_['text_feed'] = 'Просування';
$_['text_fraud'] = 'Захист від шахраїв';
$_['text_module'] = 'Модулі';
$_['text_content'] = 'Текстові модулі';
$_['text_menu'] = 'Меню';
$_['text_payment'] = 'Оплата';
$_['text_shipping'] = 'Доставка';
$_['text_theme'] = 'Теми';
$_['text_total'] = 'Враховувати в замовленні';