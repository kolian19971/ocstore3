<?php
// header
$_['heading_title'] = 'змінити пароль';

// Text
$_['text_password'] = 'Введіть новий пароль!';
$_['text_success'] = 'Ваш пароль успішно оновлено!';

// Entry
$_['entry_password'] = 'Пароль';
$_['entry_confirm'] = 'Підтвердіть пароль';

// Error
$_['error_password'] = 'Пароль повинен становити від 4 до 20 символів!';
$_['error_confirm'] = 'Паролі не збігаються!';